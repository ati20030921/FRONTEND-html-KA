﻿using BackendFeladat.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BackendFeladat.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GamersController : ControllerBase
    {
        private readonly DatabaseContext _context = new();

        //1
        [HttpGet("players/number")]
        public async Task<IActionResult> GetNumberOfGamers()
        {
            return Ok(await _context.Players.CountAsync());  
        }


        //2
        [HttpGet("/players/amount/1000")]
        public async Task<IActionResult> GetNumberOfPlayers()
        {
            return Ok(await _context.Players.Where(s => s.Amount >= 1000).ToListAsync());
        }


        // 3. /api/gamers/games/sort
        [HttpGet("games/sort")]
        public async Task<IActionResult> GetGamesSortedByTotalAmount()
        {
            var sorted = await _context.Plays
                .GroupBy(p => p.GameId)
                .Select(g => new
                {
                    Game = g.Key,
                    TotalAmount = g.Sum(x => x.Amount)
                })
                .OrderByDescending(g => g.TotalAmount)
                .ToListAsync();

            return Ok(sorted);
        }

        //[HttpGet("games/player/{id}")]
        //public async Task<IActionResult> GetGamesByPlayerId(int id)
        //{
        //    var result = await _context.Games
        //        .Where(p => p.Id == id)
        //        .ToListAsync();

        //    return Ok(result);
        //}



        [HttpDelete("players/{id}")]
        public async Task<IActionResult> DeletePlayer(int id)
        {
            var player = await _context.Players.FindAsync(id);
            if (player == null)
                return NotFound();

            _context.Players.Remove(player);
            await _context.SaveChangesAsync();

            return Ok($"Játékos {id} törölve.");
        }
    }
}
