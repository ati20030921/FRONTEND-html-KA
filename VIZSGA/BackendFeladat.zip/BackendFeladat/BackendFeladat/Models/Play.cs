﻿using System;
using System.Collections.Generic;

namespace BackendFeladat.Models;

public partial class Play
{
    public string? PlayerId { get; set; }

    public string? GameId { get; set; }

    public int? Amount { get; set; }
}
