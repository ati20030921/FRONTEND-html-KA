﻿using System;
using System.Collections.Generic;

namespace BackendFeladat.Models;

public partial class Game
{
    public string? Id { get; set; }

    public string? Game1 { get; set; }
}
