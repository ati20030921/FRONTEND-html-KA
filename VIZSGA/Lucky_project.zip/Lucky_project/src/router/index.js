import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: HomeView,
    },
    {
      path: '/lottok',
      name: 'lottok',
      component: () => import('../views/Lottok.vue'),
    },
    {
      path: '/jatek',
      name: 'jatek',
      component: () => import('../views/Jatek.vue'),
    }
  ],
})

export default router
