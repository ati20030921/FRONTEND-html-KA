<template>
  <h1 class="cim">Fogadások</h1>
  <div class="container">
    <p>Megtett játékok: </p>
    <ul>
      <li>Ötös lottó</li>
      <li>Skandináv lottó</li>
    </ul>
  </div>
</template>

<style>
.cim{
  font-size: 30px;
  text-align: center;
  font-weight: bold;
}
</style>
