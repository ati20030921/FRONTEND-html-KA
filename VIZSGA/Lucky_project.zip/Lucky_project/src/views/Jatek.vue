<template>
<h1>Lottók</h1>
<div class="container">
    <div class="card" style="width:400px">
  <img class="card-img-top" src="img_avatar1.png" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">Ötöslottó</h4>
    <p class="card-text">Az Ötöslottó játékban 90 számból kell 5-öt kiválasztani.</p>
    <a href="#" class="btn btn-primary">Játszom</a>
  </div>
</div>
<div class="card" style="width:400px">
  <img class="card-img-top" src="img_avatar1.png" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">Hatoslottó</h4>
    <p class="card-text">A Hatoslottó játékban 45 számból kell 6-ot kiválasztani.</p>
    <a href="#" class="btn btn-primary">Játszom</a>
  </div>
</div>
<div class="card" style="width:400px">
  <img class="card-img-top" src="img_avatar1.png" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">Skandináv Lottó</h4>
    <p class="card-text">A Skandináv lottó játékban 35 számból kell 7-et kiválasztani.</p>
    <a href="#" class="btn btn-primary">Játszom</a>
  </div>
</div>
<div class="card" style="width:400px">
  <img class="card-img-top" src="img_avatar1.png" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">EuroJackpot</h4>
    <p class="card-text">Az EuroJackpot játékban 50 számból kell 50 számból 5-öt és 12-ből 2-őt kiválasztani</p>
    <a href="#" class="btn btn-primary">Játszom</a>
  </div>
</div>
</div>
</template>

<script>

</script>