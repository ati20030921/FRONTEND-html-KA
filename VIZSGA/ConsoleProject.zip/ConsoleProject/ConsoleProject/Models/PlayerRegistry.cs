﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Globalization;

public class PlayerRegistry
{
    public List<Player> Players { get; set; } = new List<Player>();

    public void LoadFromCSV(string path)
    {
        if (!File.Exists(path))
        {
            Console.WriteLine("A fájl nem található!");
            return;
        }

        var lines = File.ReadAllLines(path);
        foreach (var line in lines)
        {
            var parts = line.Split(',');

            if (parts.Length != 3) continue;

            string name = parts[0];
            string email = parts[1];
            if (decimal.TryParse(parts[2], NumberStyles.Any, CultureInfo.InvariantCulture, out decimal balance))
            {
                var player = new Player(name, email, balance);
                if (player.Name != null && player.Email != null)
                {
                    Players.Add(player);
                }
            }
        }
    }

    public List<Player> GetPlayersWithBalance()
    {
        return Players.FindAll(p => p.HasBalance());
    }

    public List<Player> GetPlayersWithBalanceOver(decimal amount)
    {
        return Players.FindAll(p => p.GetBalance() > amount);
    }

    public decimal GetTotalBalance()
    {
        decimal total = 0;
        foreach (var player in Players)
        {
            total += player.GetBalance();
        }
        return total;
    }
}
