﻿using System;
using System.Text.RegularExpressions;

public class Player
{
    public string Name { get; set; }
    public string Email { get; set; }
    public decimal Balance { get; set; }

    public Player(string name, string email, decimal balance)
    {
        if (string.IsNullOrEmpty(name))
            throw new ArgumentNullException("name");

        if (string.IsNullOrEmpty(email))
            throw new ArgumentException("email");

        Name = name;
        Email = email;
        Balance = balance;
    }

    public bool HasBalance()
    {
        return Balance > 0;
    }

    public decimal GetBalance()
    {
        return Balance;
    }

    public void AddFunds(decimal amount)
    {
        if (amount <= 0)
            Console.WriteLine("Az összegnek pozitívnak kell lennie!");
        Balance += amount;
    }

    public void PlaceBet(decimal amount)
    {
        if (amount <= 0)
            Console.WriteLine("Hibás fogadási összeg!");

        if (Balance >= amount)
        {
            Balance -= amount;
        }
        else
        {
            Console.WriteLine($"Nincs elég pénzed! ({Name})");
        }
    }
}
