﻿
PlayerRegistry registry = new PlayerRegistry();
registry.LoadFromCSV("players.csv");

Console.WriteLine("Játékosok listája, akik rendelkeznek egyenleggel:");
foreach (var player in registry.GetPlayersWithBalance())
{
    Console.WriteLine($"{player.Name} - {player.GetBalance()} Ft");
}

Console.WriteLine("\nJátékosok, akiknek az egyenlege 5000 Ft felett van:");
foreach (var player in registry.GetPlayersWithBalanceOver(5000))
{
    Console.WriteLine($"{player.Name} - {player.GetBalance()} Ft");
}
Console.WriteLine($"\nA cég összesített befizetett összege: {registry.GetTotalBalance()} Ft");
 Console.ReadLine();